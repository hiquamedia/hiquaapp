// CONSTANTS
export const CURRENCY = '$';
